package com.example.sr

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
